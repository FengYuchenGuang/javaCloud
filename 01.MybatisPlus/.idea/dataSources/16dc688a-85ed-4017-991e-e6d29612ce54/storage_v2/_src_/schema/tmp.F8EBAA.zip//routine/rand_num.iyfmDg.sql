create
    definer = root@localhost function rand_num() returns int(5)
BEGIN
	DECLARE i INT DEFAULT 0;
	SET i = FLOOR(10+RAND()*500);
	RETURN i;
END;

